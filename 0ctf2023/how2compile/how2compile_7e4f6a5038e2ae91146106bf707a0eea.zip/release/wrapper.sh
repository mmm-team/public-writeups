#!/bin/bash

rustup run nightly-2023-11-03 ./task 2>/dev/null
